package com.thecodereveal.shopease.entities;

public enum PaymentStatus {
    PENDING,
    COMPLETED,
    FAILED
}
